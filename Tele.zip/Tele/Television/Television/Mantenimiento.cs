﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Television
{
    public partial class Mantenimiento : Form
    {
        private Class1 c1;

        public Mantenimiento(Class1 c1)
        {
            this.c1 = c1;
            InitializeComponent();
        }
        public Mantenimiento()
        {
            InitializeComponent();
        }

        public void llenarLogin()
        {
            this.cbLogin.DataSource = c1.getDataset().Tables["Usuarios"];
            this.cbLogin.DisplayMember = "Usuario";
        }

        private void Mantenimiento_Load(object sender, EventArgs e)
        {
            c1.conectarBaseDeDatos();
            c1.noConectado();
            llenarLogin();
            
        }

        private void cbLogin_SelectedIndexChanged(object sender, EventArgs e)
        {
           
                DataRowView reg = (DataRowView)cbLogin.SelectedItem;
                string id = reg["IdUsuario"].ToString();
                this.ckEstado.Checked = false;
                this.tbLogin.Text = reg["Usuario"].ToString();
                this.tbPass.Text = reg["Contraseña"].ToString();
                this.tbNombre.Text = reg["Nombre"].ToString();
                this.tbApellido.Text = reg["Apellidos"].ToString();
                if ((reg["Estado"].ToString() == "True"))
                {
                    this.ckEstado.Checked = true;
                }
            
        }

        private void btnGuardar_Click(object sender, EventArgs e)
        {
            if (comprobarCampos())
            {
                DataRowView r = (DataRowView)cbLogin.SelectedItem;

                r.BeginEdit();

                r["Usuario"] = this.tbLogin.Text;
                r["Contraseña"] = this.tbPass.Text;
                r["Nombre"] = this.tbNombre.Text;
                r["Apellidos"] = this.tbApellido.Text;
                r["Estado"] = this.ckEstado.Checked.ToString();

                r.EndEdit();
                c1.actualizarUsu();
                MessageBox.Show("ACTUALIZADO CORRECTAMENTE");
                limpiarPeques();
            }
            else
            {
                MessageBox.Show("Rellena todos los campos.");
            }
        }

        public void limpiarPeques()
        {
            tbApellido.Clear();
            tbLogin.Clear();
            tbNombre.Clear();
            tbPass.Clear();
            ckEstado.Checked = false;
        }

        private void btnBorrar_Click(object sender, EventArgs e)
        {
            DataRowView reg = (DataRowView)cbLogin.SelectedItem;

                DialogResult respuesta = MessageBox.Show("¿Seguro que quieres borrarlo?", "Cierre",
                    MessageBoxButtons.YesNo);
                if (respuesta == DialogResult.Yes)
                {
                    //reg.Delete();
                    c1.getDataset().Tables["Usuarios"].Rows[cbLogin.SelectedIndex].Delete();
                   // c1.actualizarUsu();
                    MessageBox.Show("Usuario Borrado");
                }
        }

        private void btnNuevo_Click(object sender, EventArgs e)
        {
          
            if (comprobarCampos())
            {
                
                
                DataRow r = c1.getDataset().Tables["Usuarios"].NewRow();
                r["Usuario"] = tbLogin.Text;
                r["Contraseña"] = tbPass.Text;
                r["Nombre"] = tbNombre.Text;
                r["Apellidos"] = tbApellido.Text;
                r["Estado"] = this.ckEstado.Checked.ToString();
                r["IdUsuario"] = ID();
                
                c1.getDataset().Tables["Usuarios"].Rows.Add(r);
                c1.actualizarUsu();
                MessageBox.Show("Usuario con id " + ID() + " Insertado");

            }
        }

        public bool comprobarCampos()
        {
            if (tbApellido.Text==""||tbLogin.Text==""||tbNombre.Text==""||tbPass.Text=="")
            {
                MessageBox.Show("Rellena todos los campos");
                return false;
            }
            else
            {
                return true;
            }
        }

        private void Mantenimiento_FormClosing(object sender, FormClosingEventArgs e)
        {
            c1.actualizarUsu();
        }

        private void btnCancelar_Click(object sender, EventArgs e)
        {
            limpiarPeques();
        }
         public int ID()
        {
            DataTable tt = c1.getDataset().Tables["Usuarios"];
            String consulta = "Max(IdUsuario)";
            String maxId = tt.Compute(consulta, string.Empty).ToString();
            int idmaxima = int.Parse(maxId)+1;
            return idmaxima;
        }
        
    }
}
