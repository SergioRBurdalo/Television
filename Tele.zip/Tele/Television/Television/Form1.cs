﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.OleDb;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Television
{
     

    public partial class Form1 : Form
    {

        OleDbConnection ctn;

        public Form1()
        {
            
            this.StartPosition = FormStartPosition.CenterScreen;
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            conectarBaseDeDatos();
            
        }

        private void conectarBaseDeDatos()
        {

            ctn = new OleDbConnection("Provider=Microsoft.Jet.OLEDB.4.0;Data Source=C:\\Temp\\Television.mdb");
            ctn.Open();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            String aux;
            String aux2;

            aux = textBox1.Text.ToString();
            aux2= textBox2.Text.ToString();

            OleDbCommand cmd;
            cmd = ctn.CreateCommand();
            cmd.CommandText = "select count(*) from Usuarios where Usuario ='"+aux+"' and Contraseña ='"+aux2+"'";

            if ((int)cmd.ExecuteScalar() > 0)
            {
                Padre f = new Padre();
                f.Show();
                this.Hide();
            }
            else
            {
                MessageBox.Show("DATOS INCORRECTOS.");
            }

            
        }
    }
}
