﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.OleDb;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Television
{
    public partial class Padre : Form
    {
        Class1 c1;
        Informes inn;
        InformeDinamico idin;
        Contenidos ct;
        Mantenimiento mn;
        ///
        private OleDbConnection ctn;
        private DataSet ds;
        private OleDbDataAdapter da;

        public Padre()
        {
            this.StartPosition = FormStartPosition.CenterScreen;
            InitializeComponent();
        }

        private void Padre_FormClosing(object sender, FormClosingEventArgs e)
        {
            Form1 fr = new Form1();
            fr.Show();
            //Application.Exit();
        }

        

        private void gestionToolStripMenuItem_Click(object sender, EventArgs e)
        {
            this.WindowState = FormWindowState.Normal;
            c1 = new Class1();

            if (mn != null)
            {
                mn.Close();
                mn = null;
            }
            if (inn != null)
            {
                inn.Close();
                inn = null;
            }
            if (idin != null)
            {
                idin.Close();
                idin = null;
            }
            if (ct == null)
            {
                ct = new Contenidos(c1);
                ct.MdiParent = this;
                this.Width = ct.Width + 22;
                this.Height = ct.Height + 67;
                ct.WindowState = FormWindowState.Maximized;
                ct.ControlBox = false; 
                ct.Show();
            }
        }

        private void usuariosToolStripMenuItem_Click(object sender, EventArgs e)
        {
            this.WindowState = FormWindowState.Normal;
            c1 = new Class1();
            if (ct != null)
            {
                ct.Close();
                ct = null;
            }
            if (inn != null)
            {
                inn.Close();
                inn = null;
            }
            if (idin != null)
            {
                idin.Close();
                idin = null;
            }
            if (mn == null)
            {
                mn = new Mantenimiento(c1);
                mn.MdiParent = this;
                this.Width = mn.Width + 22;
                this.Height = mn.Height + 67;
                mn.WindowState = FormWindowState.Maximized;
                mn.ControlBox = false; 
                mn.Show();
            }
            
        }

       
        private void Padre_Load(object sender, EventArgs e)
        {
           
        }

        private void estáticoToolStripMenuItem_Click(object sender, EventArgs e)
        {
            this.WindowState = FormWindowState.Maximized;
            c1 = new Class1();

            if (mn != null)
            {
                mn.Close();
                mn = null;
            }
            if (ct != null)
            {
                ct.Close();
                ct = null;
            }
            if (idin != null)
            {
                idin.Close();
                idin = null;
            }
            if (inn == null)
            {
                inn = new Informes(c1);
                inn.MdiParent = this;
                this.Width = inn.Width + 22;
                this.Height = inn.Height + 67;
                inn.WindowState = FormWindowState.Maximized;
                inn.ControlBox = false;
                inn.Show();
            }
        }

        private void dinámicoToolStripMenuItem_Click(object sender, EventArgs e)
        {
            this.WindowState = FormWindowState.Maximized;
            c1 = new Class1();

            if (mn != null)
            {
                mn.Close();
                mn = null;
            }
           
            if (ct != null)
            {
                ct.Close();
                ct = null;
            }
            if (inn != null)
            {
                inn.Close();
                inn = null;
            }
            if (idin == null)
            {
                idin = new InformeDinamico(c1);
                idin.MdiParent = this;
                this.Width = idin.Width + 22;
                this.Height = idin.Height + 67;
                idin.WindowState = FormWindowState.Maximized;
                idin.ControlBox = false;
                idin.Show();
            }
        }
    }
}
