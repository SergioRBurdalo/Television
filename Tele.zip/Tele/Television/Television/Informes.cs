﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Television
{
    public partial class Informes : Form
    {
        Class1 c1;
        public Informes()
        {
            InitializeComponent();
        }

        public Informes(Class1 c1)
        {
            this.c1 = c1;
            InitializeComponent();
        }

        private void crystalReportViewer1_Load(object sender, EventArgs e)
        {

        }
    }
}
