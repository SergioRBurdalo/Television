﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.OleDb;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Television
{
    public partial class Contenidos : Form
    { 
     
        Class1 c1;
        OleDbCommand cmd;
        OleDbDataAdapter da;
        DataTable dt;
        int idEmision = 0;
        
        public Contenidos()
        {
            InitializeComponent();
        }

        public Contenidos(Class1 c1)
        {
            this.c1 = c1;
            InitializeComponent();
        }

        public void llenarTodo()
        {
            //TITULO
            this.cbTitulo.DataSource = c1.getDataset().Tables["Emisiones"];
            this.cbTitulo.DisplayMember = "TituloTraducido";

            //PAIS
            this.cbPais.DataSource = c1.getDataset().Tables["PaisesProduccion"];
            this.cbPais.DisplayMember = "DescPais";

            //GENERO
            this.cbGenero.DataSource = c1.getDataset().Tables["Generos"];
            this.cbGenero.DisplayMember = "Genero";

            //SUBGENERO
            this.cbSubgenero.DataSource = c1.getDataset().Tables["Subgeneros"];
            this.cbSubgenero.DisplayMember = "Subgenero";

            //RATING
            this.cbRating.DataSource = c1.getDataset().Tables["Ratings"];
            this.cbRating.DisplayMember = "Rating";

            //EVENTOS

        }

        private void Contenidos_Load(object sender, EventArgs e)
        {
            c1.conectarBaseDeDatos();
            c1.noConectado();
            llenarTodo();
        }

        public void llenarGrid(DataGridView dgv)
        {
            try
            {
                c1.conectarBaseDeDatos();
                String titu = cbTitulo.Text.ToString();
                cmd = new OleDbCommand();
                cmd.Connection = c1.getCTN();
                cmd.CommandText = " select  idEmision from emisiones where tituloTraducido like '"+titu+"'";
                int max = Int32.Parse(cmd.ExecuteScalar().ToString());
                MessageBox.Show(max.ToString());
                //
                da = new OleDbDataAdapter("select c.NombreCanal, e.Fecha, e.Hora, e.Codificado from eventos e, canales c where e.IdCanal=c.IdCanal and e.IdEmision = " + max, c1.getCTN());
                dt = new DataTable();
                da.Fill(dt);
                dgv.DataSource = dt;
                c1.noConectado();
                    
            }catch(Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void btnBuscar_Click(object sender, EventArgs e)
        {
            if (tabControl1.SelectedTab.Equals(tabPage1))
            {
                DataRowView reg = (DataRowView)cbTitulo.SelectedItem;
                string id = reg["IdEmision"].ToString();

                this.tbTitulo.Text=reg["TituloOriginal"].ToString();
                this.tbActores.Text = reg["Actores"].ToString();
                this.tbDirector.Text = reg["Director"].ToString();
                DateTime duracion = (DateTime)reg["Duracion"];
                this.tbDuracion.Text =duracion.ToString("hh:mm:ss");
                this.tbAño.Text = reg["YearProducCION"].ToString();
                this.tbSipnosis.Text = reg["Sinopsis"].ToString();
                //Pais
                int idPais = (int)reg["idPais"];
                if (idPais != 0)
                {
                    DataRow pais = c1.getDataset().Tables["PaisesProduccion"].Select("idPais =" + idPais).First();
                    this.cbPais.Text = pais[1].ToString();
                }
                else
                {
                    this.cbPais.Text = "Pais no especificado";
                }
                //Subgenero
                int idSubgenero = (int)reg["idSubgenero"];
                DataRow subgenero = c1.getDataset().Tables["Subgeneros"].Select("idSubgenero = " + idSubgenero).First();
                this.cbSubgenero.Text = subgenero[1].ToString();

                //Genero
                int idGenero = (int)subgenero[2];
                DataRow genero = c1.getDataset().Tables["Generos"].Select("idGenero =" + idGenero).First();
                this.cbGenero.Text = genero[1].ToString();

                //Rating
                int idRating = (int)reg["idRating"];
                DataRow rating = c1.getDataset().Tables["Ratings"].Select("idRating = " + idRating).First();
                this.cbRating.Text = rating[1].ToString();
                }
                if (tabControl1.SelectedTab.Equals(tabPage2))
                {
                    llenarGrid(dataGridView1);
                }
            }
        

        private void btnSalir_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        public bool comprobarCampos()
        {
            if (tbActores.Text == "" || tbDirector.Text == "" || tbTitulo.Text == "" || tbAño.Text == "" || tbDuracion.Text == "")
            {
               
                return false;
            }
            else
            {
                return true;
            }
        }

        private void btnNuevo_Click(object sender, EventArgs e)
        {
            if(comprobarCampos())
            {
                DataRow r = c1.getDataset().Tables["Emisiones"].NewRow();
                r["TituloTraducido"] = tbTitulo.Text.ToString();
                r["TituloOriginal"] = tbTitulo.Text.ToString();

                //Pais
                DataRowView regPA = (DataRowView)cbPais.SelectedItem;
                 int idPais = (int)regPA["idPais"];
                r["idPais"] = idPais;

                //Subgenero
                DataRowView regSub = (DataRowView)cbSubgenero.SelectedItem;
                 int idSubgenero = (int)regSub["idSubgenero"];
                r["IdSubgenero"] = idSubgenero;

                //Genero
                //DataRowView regGe = (DataRowView)cbGenero.SelectedItem;
                //int idGenero = (int)regGe["IdGenero"];
                //r["IdGenero"] = idGenero;
                //Rating
                DataRowView regRa = (DataRowView)cbRating.SelectedItem;
                 int idRating = (int)regRa["idRating"];
                r["IdRating"] = idRating;

                r["YearProduccion"] = tbAño.Text.ToString();
                r["Duracion"] = Convert.ToDateTime(tbDuracion.Text);
                r["Actores"] = tbActores.Text.ToString();
                r["Director"] = tbDirector.Text.ToString();
                r["Sinopsis"] = tbSipnosis.Text.ToString();

                c1.getDataset().Tables["EMISIONES"].Rows.Add(r);

                c1.actualizarEmi();
                MessageBox.Show("AÑADIDO CORRECTAMENTE");
            }
            else
            {
                MessageBox.Show("¡Rellena todos los campos!", "Warning");
            }
            

            
        }

        public int ID()
        {
            DataTable tt = c1.getDataset().Tables["Emisiones"];
            String consulta = "Max(idEmision)";
            String maxId = tt.Compute(consulta, string.Empty).ToString();
            int idmaxima = int.Parse(maxId) + 1;
            return idmaxima;
        }

        private void btnGuardar_Click(object sender, EventArgs e)
        {
            if (comprobarCampos())
            {
                DataRowView r = (DataRowView)cbTitulo.SelectedItem;

                r.BeginEdit();

                r["TituloTraducido"] = this.tbTitulo.Text;
                r["TituloOriginal"] = this.tbTitulo.Text;

                //Pais
                DataRowView regPA = (DataRowView)this.cbPais.SelectedItem;
                int idPais = (int)regPA["idPais"];
                r["idPais"] = idPais;

                //Subgenero
                DataRowView regSub = (DataRowView)this.cbSubgenero.SelectedItem;
                int idSubgenero = (int)regSub["idSubgenero"];
                r["IdSubgenero"] = idSubgenero;

                //Genero
                //DataRowView regGe = (DataRowView)cbGenero.SelectedItem;       no necesario GENERO
                //int idGenero = (int)regGe["IdGenero"];
                //r["IdGenero"] = idGenero;

                //Rating
                DataRowView regRa = (DataRowView)cbRating.SelectedItem;
                int idRating = (int)regRa["idRating"];
                r["IdRating"] = idRating;

                r["YearProduccion"] = this.tbAño.Text.ToString();
                r["Duracion"] = this.tbDuracion.Text.ToString();
                r["Actores"] = this.tbActores.Text.ToString();
                r["Director"] = this.tbDirector.Text.ToString();
                r["Sinopsis"] = this.tbSipnosis.Text.ToString();

                r.EndEdit();
                c1.actualizarEmi();
                MessageBox.Show("ACTUALIZADO CORRECTAMENTE");
            }
            else
            {
                MessageBox.Show("¡Rellena todos los campos!", "Warnig");
            }
        }

        private void btnBorrar_Click(object sender, EventArgs e)
        {
            DataRowView reg = (DataRowView)cbTitulo.SelectedItem;

            DialogResult respuesta = MessageBox.Show("¿Seguro que quieres borrarlo?", "Cierre",
                MessageBoxButtons.YesNo);
            if (respuesta == DialogResult.Yes)
            {
                //reg.Delete();
                c1.getDataset().Tables["Usuarios"].Rows[cbTitulo.SelectedIndex].Delete();
                // c1.actualizarUsu();
                MessageBox.Show("Usuario Borrado");
            }
        }
            
    }
   }

