﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.OleDb;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Television
{

    public class Class1
    {

        private OleDbConnection ctn;
        private DataSet ds;
        private OleDbDataAdapter da;
        private OleDbDataAdapter daEmi;//NECESITO UNO POR CADA TABLA
        private OleDbDataAdapter daUsu;
        //private OleDbDataAdapter daCa;
        //private OleDbDataAdapter daEmi;
        //private OleDbDataAdapter daEmi;
        //private OleDbDataAdapter daEmi;
        //private OleDbDataAdapter daEmi;
        //private OleDbDataAdapter daEmi;

    public void conectarBaseDeDatos()
        {
            ctn = new OleDbConnection("Provider=Microsoft.Jet.OLEDB.4.0;Data Source=C:\\Temp\\Television.mdb");
            ctn.Open();
        }

    public void actualizarUsu()
        {
            ctn.Open();
            daUsu.Update(ds, "Usuarios");
            ds.AcceptChanges();
           
            ctn.Close();
        
        }

    public void actualizarEmi()
    {
        ctn.Open();
        daEmi.Update(ds, "Emisiones");
        ds.AcceptChanges();

        ctn.Close();

    }

    public void noConectado()
        {
            conectarBaseDeDatos();
            OleDbCommand cmd;
            cmd = new OleDbCommand();
            cmd.Connection = ctn;
            ds = new DataSet();
            da = new OleDbDataAdapter();

            cmd.CommandText = "Select * from Canales";
            da.SelectCommand = cmd;
            da.Fill(ds, "Canales");

            
            cmd.CommandText = "Select * from Eventos";
            da.SelectCommand = cmd;
            da.Fill(ds, "Eventos");

            cmd.CommandText = "Select * from Generos";
            da.SelectCommand = cmd;
            da.Fill(ds, "Generos");

            cmd.CommandText = "Select * from PaisesProduccion";
            da.SelectCommand = cmd;
            da.Fill(ds, "PaisesProduccion");

            cmd.CommandText = "Select * from Ratings";
            da.SelectCommand = cmd;
            da.Fill(ds, "Ratings");

            cmd.CommandText = "Select * from Subgeneros";
            da.SelectCommand = cmd;
            da.Fill(ds, "Subgeneros");

            daEmi = new OleDbDataAdapter();
            OleDbCommandBuilder cbEmi = new OleDbCommandBuilder(daEmi);
            cmd.CommandText = "Select * from Emisiones";
            daEmi.SelectCommand = cmd;
            daEmi.Fill(ds, "Emisiones");

            daUsu = new OleDbDataAdapter();
            OleDbCommandBuilder cbUsu = new OleDbCommandBuilder(daUsu);
            cmd.CommandText = "Select * from Usuarios";
            daUsu.SelectCommand = cmd;
            daUsu.Fill(ds, "Usuarios");

            ctn.Close();
 
        }
    public DataSet getDataset()
        {
            return ds;
        }

    public OleDbConnection getCTN()
    {
        return ctn;
    }

    public OleDbDataAdapter getDA()
    {
        return daEmi;
    }
    }
}
