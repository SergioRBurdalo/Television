﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.OleDb;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Television
{
    public partial class InformeDinamico : Form
    {
        Class1 c1;

        public InformeDinamico(Class1 c1)
        {
            this.c1 = c1;
            InitializeComponent();
        }
        public InformeDinamico()
        {
            InitializeComponent();
        }

        private void InformeDinamico_Load(object sender, EventArgs e)
        {
            CargarDinamico();
        }

        public void CargarDinamico()
        {
           /* String sql;
            sql = "select * from emisiones";
            OleDbDataAdapter da = new OleDbDataAdapter(sql, c1.getCTN());

            da.Fill(Datos????,"Emisiones");

            //CREARinforme crReservas
            Informeeeeeee????.SetDataSource(Datos???.Tables("Reservas"));
            crystalReportViewer1.ReportSource = Informeeeeeee????;
            * */
        }

        private void btnBuscar_Click(object sender, EventArgs e)
        {

        }
    }
}
